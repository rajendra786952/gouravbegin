import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-faculty-single-video',
  templateUrl: './faculty-single-video.component.html',
  styleUrls: ['./faculty-single-video.component.css']
})
export class FacultySingleVideoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
