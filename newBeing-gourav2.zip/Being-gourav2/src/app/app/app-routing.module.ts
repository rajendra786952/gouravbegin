import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from '../home/home.component';
import { LoginComponent } from '../login/login.component';
import { JoinfreeComponent } from '../joinfree/joinfree.component';
import { AboutComponent } from '../about/about.component';
import { OurstoryComponent } from '../ourstory/ourstory.component';
import { VideoComponent } from '../video/video.component';
import { PortfolioComponent } from '../portfolio/portfolio.component';
import { GalleryComponent } from '../gallery/gallery.component';
import { BlogComponent } from '../blog/blog.component';
import { ContactComponent } from '../contact/contact.component';
import { PrivacyComponent } from '../privacy/privacy.component';
import { TermsComponent } from '../terms/terms.component';
import { RegisterComponent } from '../register/register.component';
import { VisionComponent } from '../vision/vision.component';
import { BuybookComponent } from '../buybook/buybook.component';
import { VideoMainCategoryComponent } from '../video-main-category/video-main-category.component';
import { SingalCategoryComponent } from '../singal-category/singal-category.component';
import { MainCoursesVideoComponent } from '../main-courses-video/main-courses-video.component';
import { FacultySingleVideoComponent } from '../faculty-single-video/faculty-single-video.component';
import { SingleBlogComponent } from '../single-blog/single-blog.component';


const routes: Routes = [
  {
    path: '',
    redirectTo: 'homepage',
    pathMatch: 'full',
  },
  {
    path:'homepage',
    component:HomeComponent
  },
  {
    path:'login',
    component:LoginComponent
  },
  {
    path:'joinfree',
    component:JoinfreeComponent
  },
  {
    path:'about',
    component:AboutComponent
  },
  {
    path:'ourstory',
    component:OurstoryComponent
  },
  {
    path:'video',
    component:VideoComponent
  },
  {
    path:'portfolio',
    component:PortfolioComponent
  },
  {
    path:'gallery',
    component:GalleryComponent
  },
  {
    path:'blog',
    component:BlogComponent
  },
  {
    path:'contact',
    component:ContactComponent
  },
  {
    path:'privacy',
    component:PrivacyComponent
  },
  {
    path:'terms',
    component:TermsComponent
  },
  {
    path:'register',
    component:RegisterComponent
  },
  {
    path:'vision',
    component:VisionComponent
  },
  {
    path:'buybook',
    component:BuybookComponent
  },
  {
    path:'video_main_category',
    component:VideoMainCategoryComponent
  },
  {
    path:'singal-category',
    component:SingalCategoryComponent
  },
  {
    path:'main-course-video',
    component:MainCoursesVideoComponent
  },
  {
    path:'faculty-single-video',
    component:FacultySingleVideoComponent
  },
  {
    path:'single-blog',
    component:SingleBlogComponent
  },
  { path: '**', 
    component: HomeComponent 
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes,{
    initialNavigation:'enabled'
  })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
