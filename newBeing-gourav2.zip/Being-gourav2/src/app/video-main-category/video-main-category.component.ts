import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-video-main-category',
  templateUrl: './video-main-category.component.html',
  styleUrls: ['./video-main-category.component.css']
})
export class VideoMainCategoryComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
  }
  singal_category()
  {
    console.log("hi");
    this.router.navigate(["singal-category"]);
  }
  videomain()
  {
    this.router.navigate(['video_main_category']);
  }
}


