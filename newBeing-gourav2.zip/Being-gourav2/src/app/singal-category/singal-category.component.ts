import { Component, OnInit } from '@angular/core';
import { Route } from '@angular/compiler/src/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-singal-category',
  templateUrl: './singal-category.component.html',
  styleUrls: ['./singal-category.component.css']
})
export class SingalCategoryComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
  }
  videomain()
  {
    this.router.navigate(['video_main_category']);
  }
  mainvideocourse()
  {
    this.router.navigate(['main-course-video']);
  }
  faculty_single_video()
  {
    this.router.navigate(['faculty-single-video']);
  }
}
