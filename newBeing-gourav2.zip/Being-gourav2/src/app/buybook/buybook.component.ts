import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buybook',
  templateUrl: './buybook.component.html',
  styleUrls: ['./buybook.component.css']
})
export class BuybookComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
