import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-joinfree',
  templateUrl: './joinfree.component.html',
  styleUrls: ['./joinfree.component.css']
})
export class JoinfreeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
